using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AppIdoso2._0.Pages
{
    public class DicasModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
