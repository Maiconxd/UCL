using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

var builder = WebApplication.CreateBuilder(args);

// Adiciona servi�os ao container, incluindo suporte a Razor Pages
builder.Services.AddRazorPages();

var app = builder.Build();

// Configura o pipeline HTTP

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    // HSTS - seguran�a para produ��o
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles(); // Habilita uso de arquivos est�ticos (CSS, JS, imagens)

app.UseRouting();

app.UseAuthorization();

app.MapRazorPages();

app.Run();
